# 의류 쇼핑몰 스타터 (정적 사이트)

이 저장소는 바로 배포 가능한 **정적(Static) 쇼핑몰** 템플릿입니다. 상품/장바구니/사이즈표/정책 페이지가 포함되어 있습니다.

## 빠른 시작

1. 압축을 풀고 폴더를 그대로 업로드하세요.
   - **GitHub Pages**: `Settings > Pages` 에서 배포
   - **Netlify/Vercel**: New Project로 폴더 배포
   - **카페24/아임웹/식스샵**: 자체 테마를 쓰되, 이 템플릿의 텍스트/정책/이미지를 참고해 이동

2. **브랜드 수정**
   - `assets/js/config.js`에서 `storeName`, `storeTagline`, `contactEmail`, `freeShippingThreshold`를 변경

3. **상품 수정**
   - `products.json`에서 상품을 추가/편집 (가격 단위 KRW). `images`에는 내부 이미지 경로나 데이터URI를 넣을 수 있습니다.

4. **정책/문의**
   - `terms.html`, `privacy.html`, `returns.html`, `contact.html`를 실제 운영에 맞게 수정

> ⚠️ 실제 결제를 받으려면 PG(토스페이먼츠/이니시스/네이버페이/카카오페이 등) 또는 Shopify/카페24와 같은 SaaS의 체크아웃을 연동하세요.

## 구조

```
/
├─ index.html          # 홈
├─ collection.html     # 전체상품
├─ product.html        # 상품 상세
├─ cart.html           # 장바구니 (localStorage)
├─ checkout.html       # 결제(데모)
├─ size.html           # 사이즈표
├─ terms.html / privacy.html / returns.html / contact.html
├─ products.json       # 상품 데이터
└─ assets/
   ├─ css/styles.css
   ├─ js/config.js, app.js
   └─ logo-*.svg
```

## 라이선스

템플릿 소스는 상업적 사용 가능. (로고/텍스트는 예시이므로 교체 권장)