window.SHOP_CONFIG = {
  storeName: "NABIWEAR",
  storeTagline: "편안함과 데일리 사이, 나비웨어",
  currency: "KRW",
  contactEmail: "hello@nabiwear.example",
  shippingNotice: "오전 11시 이전 결제건은 당일 출고(영업일 기준)",
  freeShippingThreshold: 70000
};